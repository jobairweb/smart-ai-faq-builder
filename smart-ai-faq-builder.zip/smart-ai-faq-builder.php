<?php
/**
 * Plugin Name: Smart AI FAQ Builder (Free Edition)
 * Plugin URI: https://yourwebsite.com
 * Description: Automatically generates FAQ sections from page or post content - 100% FREE, no API needed!
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://yourwebsite.com
 * License: GPL v2 or later
 * Text Domain: smart-ai-faq
 */

if (!defined('ABSPATH')) exit;

class Smart_AI_FAQ_Builder {
    
    private $option_name = 'smart_ai_faq_settings';
    
    public function __construct() {
        add_action('add_meta_boxes', [$this, 'add_meta_box']);
        add_action('wp_ajax_generate_ai_faq', [$this, 'generate_ai_faq']);
        add_action('admin_enqueue_scripts', [$this, 'admin_scripts']);
        add_action('wp_enqueue_scripts', [$this, 'frontend_scripts']);
        add_action('admin_menu', [$this, 'add_settings_page']);
        add_action('admin_init', [$this, 'register_settings']);
        add_shortcode('smart_ai_faq', [$this, 'faq_shortcode']);
        add_filter('the_content', [$this, 'auto_insert_faq']);
    }
    
    public function add_meta_box() {
        add_meta_box(
            'smart_ai_faq_box',
            __('🎯 Generate FAQ (100% Free)', 'smart-ai-faq'),
            [$this, 'meta_box_html'],
            ['post', 'page'],
            'side',
            'default'
        );
    }
    
    public function meta_box_html($post) {
        wp_nonce_field('smart_ai_faq_nonce', 'smart_ai_faq_nonce_field');
        $faq_data = get_post_meta($post->ID, '_smart_ai_faq', true);
        ?>
        <div id="smart-faq-generator">
            <p style="color:#666; font-size:12px; margin-bottom:10px;">
                ✨ No API needed - 100% free local generation
            </p>
            <button type="button" id="generate-faq-btn" class="button button-primary" style="width:100%; margin-bottom:10px;">
                <?php echo $faq_data ? __('🔄 Regenerate FAQ', 'smart-ai-faq') : __('✨ Generate FAQ Now', 'smart-ai-faq'); ?>
            </button>
            <div id="faq-loading" style="display:none; text-align:center; margin:10px 0;">
                <span class="spinner is-active" style="float:none;"></span>
                <p><?php _e('Analyzing content...', 'smart-ai-faq'); ?></p>
            </div>
            <div id="faq-error" style="display:none; color:#d63638; margin:10px 0;"></div>
            <label for="smart_faq_content"><?php _e('Generated FAQ:', 'smart-ai-faq'); ?></label>
            <textarea id="smart_faq_content" name="smart_faq_content" rows="10" style="width:100%; margin-top:5px;"><?php echo esc_textarea($faq_data); ?></textarea>
            <p class="description"><?php _e('✏️ Edit before saving the post.', 'smart-ai-faq'); ?></p>
        </div>
        <?php
    }
    
    public function generate_ai_faq() {
        check_ajax_referer('smart_ai_faq_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(['message' => 'Permission denied']);
        }
        
        $post_id = intval($_POST['post_id']);
        $post = get_post($post_id);
        
        if (!$post) {
            wp_send_json_error(['message' => 'Post not found']);
        }
        
        $settings = get_option($this->option_name);
        $faq_count = isset($settings['faq_count']) ? intval($settings['faq_count']) : 6;
        
        // Extract content and analyze
        $content = $post->post_content;
        $title = $post->post_title;
        
        // Generate FAQ using local analysis
        $faq_text = $this->local_faq_generator($content, $title, $faq_count);
        
        if (empty($faq_text)) {
            wp_send_json_error(['message' => 'Could not generate FAQ. Try adding more headings or content.']);
        }
        
        update_post_meta($post_id, '_smart_ai_faq', sanitize_textarea_field($faq_text));
        
        wp_send_json_success(['faq' => $faq_text]);
    }
    
    /**
     * Local FAQ Generator - No API Required
     */
    private function local_faq_generator($content, $title, $count = 6) {
        $faqs = [];
        
        // Remove shortcodes and HTML
        $clean_content = wp_strip_all_tags(strip_shortcodes($content));
        $clean_content = preg_replace('/\s+/', ' ', $clean_content);
        
        // Extract headings (potential questions)
        preg_match_all('/<h[2-4][^>]*>(.*?)<\/h[2-4]>/i', $content, $headings);
        
        // Strategy 1: Convert H2/H3 headings to questions
        if (!empty($headings[1])) {
            foreach ($headings[1] as $heading) {
                $heading = wp_strip_all_tags($heading);
                if (strlen($heading) > 10 && strlen($heading) < 100) {
                    $question = $this->heading_to_question($heading);
                    $answer = $this->extract_context_for_heading($content, $heading);
                    $faqs[] = ['q' => $question, 'a' => $answer];
                }
            }
        }
        
        // Strategy 2: Detect question patterns in content
        preg_match_all('/([^.!?]+\?)/u', $clean_content, $questions);
        if (!empty($questions[1])) {
            foreach ($questions[1] as $q) {
                $q = trim($q);
                if (strlen($q) > 15 && strlen($q) < 150) {
                    $answer = $this->find_answer_near_question($clean_content, $q);
                    $faqs[] = ['q' => $q, 'a' => $answer];
                }
            }
        }
        
        // Strategy 3: Generate questions from keywords
        $keywords = $this->extract_keywords($clean_content, $title);
        foreach ($keywords as $keyword) {
            $question = $this->keyword_to_question($keyword, $title);
            $answer = $this->extract_context_for_keyword($clean_content, $keyword);
            $faqs[] = ['q' => $question, 'a' => $answer];
        }
        
        // Strategy 4: Common question templates
        $common_templates = [
            "What is {topic}?",
            "How does {topic} work?",
            "Why is {topic} important?",
            "What are the benefits of {topic}?",
            "How can I get started with {topic}?",
        ];
        
        $main_topic = $this->extract_main_topic($title);
        foreach ($common_templates as $template) {
            $question = str_replace('{topic}', $main_topic, $template);
            $answer = $this->extract_context_for_keyword($clean_content, $main_topic);
            if (!empty($answer)) {
                $faqs[] = ['q' => $question, 'a' => $answer];
            }
        }
        
        // Remove duplicates and limit count
        $faqs = $this->deduplicate_faqs($faqs);
        $faqs = array_slice($faqs, 0, $count);
        
        // Format output
        $output = '';
        foreach ($faqs as $faq) {
            $output .= "Q: " . $faq['q'] . "\n";
            $output .= "A: " . $faq['a'] . "\n\n";
        }
        
        return trim($output);
    }
    
    private function heading_to_question($heading) {
        $heading = trim($heading);
        
        // If already a question, return as is
        if (substr($heading, -1) === '?') {
            return $heading;
        }
        
        // Convert to question format
        $question_starters = [
            'benefits' => 'What are the benefits of ',
            'how to' => '',
            'guide to' => 'How can I use ',
            'tips' => 'What are some tips for ',
            'best practices' => 'What are the best practices for ',
            'introduction' => 'What is ',
            'overview' => 'What is ',
        ];
        
        $lower_heading = strtolower($heading);
        foreach ($question_starters as $pattern => $prefix) {
            if (strpos($lower_heading, $pattern) !== false) {
                return $prefix . $heading . '?';
            }
        }
        
        // Default: add "What is" or "How to"
        if (preg_match('/\b(use|install|setup|configure|create|build)\b/i', $heading)) {
            return 'How to ' . $heading . '?';
        }
        
        return 'What is ' . $heading . '?';
    }
    
    private function extract_context_for_heading($content, $heading) {
        $clean_content = wp_strip_all_tags($content);
        $pos = stripos($clean_content, $heading);
        
        if ($pos === false) {
            return $this->extract_first_sentences($clean_content, 2);
        }
        
        // Get text after heading
        $after = substr($clean_content, $pos + strlen($heading));
        return $this->extract_first_sentences($after, 2);
    }
    
    private function extract_keywords($content, $title) {
        $words = str_word_count(strtolower($content . ' ' . $title), 1);
        $word_counts = array_count_values($words);
        
        // Filter out common words
        $stop_words = ['the', 'is', 'at', 'which', 'on', 'a', 'an', 'as', 'are', 'was', 'were', 'been', 'be', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'must', 'can', 'this', 'that', 'these', 'those', 'i', 'you', 'he', 'she', 'it', 'we', 'they', 'what', 'who', 'when', 'where', 'why', 'how', 'and', 'or', 'but', 'in', 'out', 'up', 'down', 'from', 'to', 'with', 'for', 'of', 'by'];
        
        foreach ($stop_words as $stop) {
            unset($word_counts[$stop]);
        }
        
        // Remove short words
        $word_counts = array_filter($word_counts, function($word) {
            return strlen($word) > 4;
        }, ARRAY_FILTER_USE_KEY);
        
        arsort($word_counts);
        return array_slice(array_keys($word_counts), 0, 5);
    }
    
    private function keyword_to_question($keyword, $title) {
        $templates = [
            "How can I use {keyword}?",
            "What is {keyword}?",
            "Why should I consider {keyword}?",
            "What are the advantages of {keyword}?",
        ];
        
        $template = $templates[array_rand($templates)];
        return str_replace('{keyword}', $keyword, $template);
    }
    
    private function extract_context_for_keyword($content, $keyword) {
        $sentences = preg_split('/[.!?]+/', $content);
        
        foreach ($sentences as $sentence) {
            if (stripos($sentence, $keyword) !== false) {
                $sentence = trim($sentence);
                if (strlen($sentence) > 30) {
                    return $sentence . '.';
                }
            }
        }
        
        return $this->extract_first_sentences($content, 2);
    }
    
    private function find_answer_near_question($content, $question) {
        $pos = stripos($content, $question);
        
        if ($pos !== false) {
            $after = substr($content, $pos + strlen($question));
            return $this->extract_first_sentences($after, 2);
        }
        
        return $this->extract_first_sentences($content, 2);
    }
    
    private function extract_first_sentences($text, $count = 2) {
        $sentences = preg_split('/[.!?]+/', $text);
        $result = [];
        
        foreach ($sentences as $sentence) {
            $sentence = trim($sentence);
            if (strlen($sentence) > 20) {
                $result[] = $sentence;
                if (count($result) >= $count) break;
            }
        }
        
        return implode('. ', $result) . '.';
    }
    
    private function extract_main_topic($title) {
        $words = explode(' ', $title);
        $words = array_filter($words, function($word) {
            return strlen($word) > 3;
        });
        return implode(' ', array_slice($words, 0, 3));
    }
    
    private function deduplicate_faqs($faqs) {
        $unique = [];
        $seen_questions = [];
        
        foreach ($faqs as $faq) {
            $q_lower = strtolower(trim($faq['q']));
            if (!in_array($q_lower, $seen_questions) && !empty($faq['a'])) {
                $unique[] = $faq;
                $seen_questions[] = $q_lower;
            }
        }
        
        return $unique;
    }
    
    public function admin_scripts($hook) {
        if ('post.php' !== $hook && 'post-new.php' !== $hook) return;
        
        wp_enqueue_script('smart-faq-admin', plugin_dir_url(__FILE__) . 'assets/admin.js', ['jquery'], '1.0', true);
        wp_localize_script('smart-faq-admin', 'smartFaqAjax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('smart_ai_faq_nonce')
        ]);
    }
    
    public function frontend_scripts() {
        if (has_shortcode(get_post()->post_content ?? '', 'smart_ai_faq') || get_option($this->option_name)['auto_insert'] ?? false) {
            wp_enqueue_style('smart-faq-style', plugin_dir_url(__FILE__) . 'assets/style.css', [], '1.0');
            wp_enqueue_script('smart-faq-frontend', plugin_dir_url(__FILE__) . 'assets/frontend.js', ['jquery'], '1.0', true);
        }
    }
    
    public function add_settings_page() {
        add_options_page(
            __('Smart FAQ Settings', 'smart-ai-faq'),
            __('Smart FAQ', 'smart-ai-faq'),
            'manage_options',
            'smart-ai-faq',
            [$this, 'settings_page_html']
        );
    }
    
    public function register_settings() {
        register_setting('smart_ai_faq_group', $this->option_name);
        
        add_settings_section('smart_ai_faq_section', __('FAQ Settings', 'smart-ai-faq'), null, 'smart-ai-faq');
        
        add_settings_field('faq_count', __('Default FAQ Count', 'smart-ai-faq'), [$this, 'faq_count_field'], 'smart-ai-faq', 'smart_ai_faq_section');
        add_settings_field('auto_insert', __('Auto Insert FAQ', 'smart-ai-faq'), [$this, 'auto_insert_field'], 'smart-ai-faq', 'smart_ai_faq_section');
    }
    
    public function faq_count_field() {
        $settings = get_option($this->option_name);
        $value = isset($settings['faq_count']) ? $settings['faq_count'] : 6;
        echo '<input type="number" name="' . $this->option_name . '[faq_count]" value="' . esc_attr($value) . '" min="3" max="10" class="small-text"> <span class="description">Number of FAQs to generate (3-10)</span>';
    }
    
    public function auto_insert_field() {
        $settings = get_option($this->option_name);
        $value = isset($settings['auto_insert']) ? $settings['auto_insert'] : false;
        echo '<label><input type="checkbox" name="' . $this->option_name . '[auto_insert]" value="1" ' . checked($value, 1, false) . '> Automatically append FAQ below post content</label>';
    }
    
    public function settings_page_html() {
        ?>
        <div class="wrap">
            <h1>🎯 <?php _e('Smart FAQ Builder Settings', 'smart-ai-faq'); ?></h1>
            <div style="background:#e7f5ff; border-left:4px solid #1c7ed6; padding:15px; margin:20px 0;">
                <strong>✨ 100% Free Edition</strong> - No API keys needed! Uses smart local content analysis.
            </div>
            <form method="post" action="options.php">
                <?php
                settings_fields('smart_ai_faq_group');
                do_settings_sections('smart-ai-faq');
                submit_button();
                ?>
            </form>
            <hr>
            <h2><?php _e('📖 How It Works', 'smart-ai-faq'); ?></h2>
            <ul>
                <li>✅ Analyzes your post headings (H2, H3)</li>
                <li>✅ Detects existing questions in content</li>
                <li>✅ Extracts important keywords</li>
                <li>✅ Generates contextual answers</li>
                <li>✅ 100% free - no API costs!</li>
            </ul>
            <h2><?php _e('🚀 Usage', 'smart-ai-faq'); ?></h2>
            <ol>
                <li>Edit any post/page</li>
                <li>Click <strong>"Generate FAQ Now"</strong> in sidebar</li>
                <li>Review and edit generated FAQ</li>
                <li>Save post</li>
                <li>Use shortcode <code>[smart_ai_faq]</code> to display</li>
            </ol>
        </div>
        <?php
    }
    
    public function faq_shortcode($atts) {
        global $post;
        if (!$post) return '';
        
        $faq_text = get_post_meta($post->ID, '_smart_ai_faq', true);
        if (empty($faq_text)) return '';
        
        return $this->format_faq_output($faq_text);
    }
    
    public function auto_insert_faq($content) {
        $settings = get_option($this->option_name);
        if (!isset($settings['auto_insert']) || !$settings['auto_insert']) return $content;
        
        if (!is_singular(['post', 'page'])) return $content;
        
        global $post;
        $faq_text = get_post_meta($post->ID, '_smart_ai_faq', true);
        if (empty($faq_text)) return $content;
        
        return $content . $this->format_faq_output($faq_text);
    }
    
    private function format_faq_output($faq_text) {
        $items = preg_split('/Q:\s*/i', $faq_text);
        $output = '<div class="smart-faq" itemscope itemtype="https://schema.org/FAQPage">';
        
        foreach ($items as $item) {
            if (empty(trim($item))) continue;
            
            $parts = preg_split('/A:\s*/i', $item, 2);
            if (count($parts) < 2) continue;
            
            $question = trim($parts[0]);
            $answer = trim($parts[1]);
            
            $output .= '<div class="faq-item" itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">';
            $output .= '<h4 class="faq-question" itemprop="name">' . esc_html($question) . '</h4>';
            $output .= '<div class="faq-answer" itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer"><div itemprop="text">' . wpautop(esc_html($answer)) . '</div></div>';
            $output .= '</div>';
        }
        
        $output .= '</div>';
        return $output;
    }
}

// Save FAQ when post is saved
add_action('save_post', function($post_id) {
    if (!isset($_POST['smart_ai_faq_nonce_field']) || !wp_verify_nonce($_POST['smart_ai_faq_nonce_field'], 'smart_ai_faq_nonce')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;
    
    if (isset($_POST['smart_faq_content'])) {
        update_post_meta($post_id, '_smart_ai_faq', sanitize_textarea_field($_POST['smart_faq_content']));
    }
});

new Smart_AI_FAQ_Builder();
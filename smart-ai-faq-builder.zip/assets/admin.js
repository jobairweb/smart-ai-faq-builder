jQuery(document).ready(function($) {
    $('#generate-faq-btn').on('click', function(e) {
        e.preventDefault();
        
        var btn = $(this);
        var postId = $('#post_ID').val();
        var loading = $('#faq-loading');
        var error = $('#faq-error');
        var textarea = $('#smart_faq_content');
        
        // Reset states
        error.hide();
        loading.show();
        btn.prop('disabled', true);
        
        $.ajax({
            url: smartFaqAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'generate_ai_faq',
                post_id: postId,
                nonce: smartFaqAjax.nonce
            },
            success: function(response) {
                loading.hide();
                btn.prop('disabled', false);
                
                if (response.success) {
                    textarea.val(response.data.faq);
                    btn.text('🔄 Regenerate FAQ');
                    
                    // Show success message
                    var notice = $('<div class="notice notice-success is-dismissible"><p>FAQ generated successfully! Review and save the post.</p></div>');
                    $('#smart-faq-generator').prepend(notice);
                    setTimeout(function() {
                        notice.fadeOut(function() { $(this).remove(); });
                    }, 3000);
                } else {
                    error.text('Error: ' + response.data.message).show();
                }
            },
            error: function() {
                loading.hide();
                btn.prop('disabled', false);
                error.text('Connection error. Please try again.').show();
            }
        });
    });
});
jQuery(document).ready(function($) {
    $('.smart-faq .faq-question').on('click', function() {
        var item = $(this).closest('.faq-item');
        var answer = item.find('.faq-answer');
        
        // Close other items
        $('.smart-faq .faq-item').not(item).removeClass('active').find('.faq-answer').slideUp(300);
        
        // Toggle current item
        item.toggleClass('active');
        answer.slideToggle(300);
    });
    
    // Open first item by default
    $('.smart-faq .faq-item:first-child').addClass('active').find('.faq-answer').show();
});